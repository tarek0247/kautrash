# Kauno Švara

Web app for official **UAB Kauno švara** collection dates. Pick a Lithuanian address (or use location), and the app loads the live calendar from [grafikai.svara.lt](https://grafikai.svara.lt).

Street and house number stay **hidden on Home and Settings** by default. They are stored only on this device.

تطبيق ويب لمواعيد جمع النفايات الرسمية من كاوناس شفارا. العنوان يبقى مخفياً على الشاشة إلا إذا فتحت التعديل بنفسك.

## Stack

- Node.js 22
- TanStack Start + React 19
- Tailwind CSS v4
- Deploys to **Vercel** (`nitro` Vercel preset)

## Features

- Official Lithuanian address register (municipality → eldership → settlement → street → house)
- Optional GPS (“Use my location”)
- Live Švara collection schedule
- Calendar view
- Sorting guide (mixed / paper / glass / organic)
- English and Lithuanian
- Privacy toggle to hide the saved street on screen

## Run locally

```bash
npm install
npm run dev
```

Then open the URL Vite prints (default port 8080).

```bash
npm run build
npm run typecheck
```

## Deploy on Vercel

1. Import this GitHub repository in [Vercel](https://vercel.com/new).
2. Framework: **Other** (Nitro writes `.vercel/output` during `npm run build`).
3. Build command: `npm run build`
4. Install command: `npm install`
5. No environment variables are required for the schedule lookup.

Unofficial companion — not affiliated with UAB Kauno švara.
